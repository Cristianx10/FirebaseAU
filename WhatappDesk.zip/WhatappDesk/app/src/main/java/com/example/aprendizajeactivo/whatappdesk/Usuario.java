package com.example.aprendizajeactivo.whatappdesk;

public class Usuario {

    public String name;
    public String email;
    public String pass;
    public String uid;

    public Usuario(){}

}
