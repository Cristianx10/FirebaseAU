package com.example.aprendizajeactivo.whatappdesk;

public class Mensaje {

    public String mensaje;
    public String usuario;

    public Mensaje(){}
}
