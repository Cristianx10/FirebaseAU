package com.example.aprendizajeactivo.whatappdesk;

import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.Query;

public class Login extends AppCompatActivity implements settingList {

    private EditText et_mensaje;
    private Button btn_enviar;
    private ListView lv_lista;
    private TextView tv_numero;

    ListaFirebase<Mensaje> list;
    FirebaseAU au;
    String nombre = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        et_mensaje = findViewById(R.id.et_mensaje);
        btn_enviar = findViewById(R.id.btn_enviar);
        lv_lista = findViewById(R.id.lv_lista);
        tv_numero = findViewById(R.id.tv_numero);

        au.getIntance();

        final DatabaseReference reference = au.getReferencia().child("Chat");



        au.readObjectReference(new FirebaseAU.DataObjectListener() {
            @Override
            public DatabaseReference getReferenceDataBase() {
                return au.getReferencia().child("Usuario").child(au.getUserUid());
            }

            @Override
            public void getObjectReference(@NonNull DataSnapshot dataSnapshot) {
                Usuario user = (Usuario) au.convertObjectTo(dataSnapshot, Usuario.class);
                nombre = user.name;
            }
        });

        au.readObjectRealTime(new FirebaseAU.DataObjectListener() {
            @Override
            public DatabaseReference getReferenceDataBase() {
                return au.getReferencia().child("Chat");
            }


            @Override
            public void getObjectReference(@NonNull DataSnapshot dataSnapshot) {
                String num = dataSnapshot.getChildrenCount() + "";
               tv_numero.setText("Numero mensajes:  " + num);
            }
        });


        btn_enviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Mensaje m = new Mensaje();
                m.mensaje = et_mensaje.getText().toString();
                m.usuario = nombre;

                au.guardaObjeto(reference, m);
            }
        });




        list = new ListaFirebase<>(new ListaFirebase.getVariables<Mensaje>() {
            @Override
            public ListView getViewListas() {
                return lv_lista;
            }

            @Override
            public Query getUbicacionBase() {
                return au.getReferencia().child("Chat");
            }

            @Override
            public Class getClaseModelo() {
                return Mensaje.class;
            }

            @Override
            public int getLayoutList() {
                return R.layout.renglon;
            }

            @Override
            public void populateView(@NonNull View v, @NonNull Mensaje model, int position) {

                TextView nombre = v.findViewById(R.id.tv_usuario);
                TextView mensaje = v.findViewById(R.id.tv_mensaje);

                nombre.setText(model.usuario);
                mensaje.setText(model.mensaje);


            }
        });


    }

    @Override
    public void onStart() {
        super.onStart();
        list.startList();
    }

    @Override
    public void onStop() {
        super.onStop();
        list.stopList();
    }
}
