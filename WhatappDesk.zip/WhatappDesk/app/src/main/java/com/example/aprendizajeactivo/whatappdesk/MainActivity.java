package com.example.aprendizajeactivo.whatappdesk;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.database.DatabaseReference;

public class MainActivity extends AppCompatActivity {


    private EditText et_nombre;
    private EditText et_email;
    private EditText et_password;
    private Button btn_login;
    private Button btn_registro;

    FirebaseAU au;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        et_nombre = findViewById(R.id.et_nombre);
        et_email = findViewById(R.id.et_email);
        et_password = findViewById(R.id.et_password);
        btn_login = findViewById(R.id.btn_login);
        btn_registro = findViewById(R.id.btn_registro);

    au.getIntance();

     //   FirebaseAuth auth = FirebaseAuth.getInstance();




    btn_registro.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            accionRegistrar();
        }
    });

    btn_login.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            login();
        }
    });



    }

    public void accionRegistrar(){
        au.createWithEmailAndPassword(et_email, et_password, new FirebaseAU.DataUserValidation() {
            @Override
            public void actionIsSuccessful(@NonNull Task<AuthResult> task) {
                DatabaseReference reference = au.getReferencia().child("Usuario");
                Usuario user= new Usuario();
                user.name =et_nombre.getText().toString();
                user.email =et_email.getText().toString();
                user.pass =et_password.getText().toString();
                user.uid =au.getUserUid();

                au.guardaEnUidUsuario(reference, user);

                //Forma larga
                //reference.push().setValue(user);
            }

            @Override
            public void actionErrorException(@NonNull Task<AuthResult> task) {

            }
        });

    }

    public void login(){
        au.loginWithEmailAndPassword(et_email, et_password, new FirebaseAU.DataUserValidation() {
            @Override
            public void actionIsSuccessful(@NonNull Task<AuthResult> task) {
                Intent irALogin= new Intent(MainActivity.this, Login.class);
                startActivity(irALogin);
            }

            @Override
            public void actionErrorException(@NonNull Task<AuthResult> task) {

            }
        });

    }

}
